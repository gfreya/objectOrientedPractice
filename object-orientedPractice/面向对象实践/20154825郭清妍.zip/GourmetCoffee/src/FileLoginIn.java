import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class FileLoginIn {
	public FileLoginIn(){
		File file = new File("name.dat");
		try {
			FileWriter out = new FileWriter(file);
			out.write("Guo Qingyan ");
			out.write("Zhou Xinhao ");
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		File file1 = new File("Number.dat");
			try {
				FileWriter fout = new FileWriter(file1);
				fout.write("123");
				fout.write("124");
				fout.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
}

