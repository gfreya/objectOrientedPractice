/**
 * interface of the format of the sales information
 * @version 1.0
 * @author Guoqy
 *
 */
public interface SalesFormatter {
		public String formatSales(Sales sales);

}

