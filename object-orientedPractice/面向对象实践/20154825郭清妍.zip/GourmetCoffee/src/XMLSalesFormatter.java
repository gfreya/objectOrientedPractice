
public class XMLSalesFormatter implements SalesFormatter{
	private static XMLSalesFormatter singletonInstance=null;
	
	static public XMLSalesFormatter getSingletonInstance(){
		if(singletonInstance==null){
			singletonInstance = new XMLSalesFormatter();
		}
		return singletonInstance;
	}
	
	private XMLSalesFormatter(){
		
	}
	
	public String formatSales(Sales sales){
		String str="";
		str+="<Sales>\n";
		for(Order o:sales.orders){
			str+="  <Order total=\""+(float)o.getTotalCost()+"\">\n";
			for(int j=0;j<o.getItems().size();){
				str+="    <OrderItem quantity=\""+o.getItems().get(j).getQuantity()+"\" price=\""+o.getItems().get(j).getValue()+"\">"+o.getItems().get(j).getProduct().getCode()+"</OrderItem>\n";
				j=j+o.getItems().get(j).getQuantity();
			}
			str+="  </order>\n";
		}
		str+="</Sales>\n";
		return str;
	}
}




