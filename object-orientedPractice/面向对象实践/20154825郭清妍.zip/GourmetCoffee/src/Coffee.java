import java.io.Serializable;

/** 
 * @author guoqy
 * @version 1.0
 * @para six parameters:origin roast flavor aroma acidity body
 * basic functions of getting and setting the attributes of the product 
 * 		 overrides the toString method to show the information of the product
 */
public class Coffee extends Product implements Serializable{
	private String origin;
	private String roast;
	private String flavor;
	private String aroma;
	private String acidity;
	private String body;
	
	/**
	 * 
	 * @param code
	 * @param description
	 * @param price
	 * @param amount
	 * @param origin
	 * @param roast
	 * @param flavor
	 * @param aroma
	 * @param acidity
	 * @param body
	 */
	public Coffee(String code,String description,double price,int amount,String origin,String roast,String flavor,String aroma,String acidity,String body){
		super(code,description,price,amount);
		this.origin = origin;
		this.roast = roast;
		this.flavor = flavor;
		this.aroma =aroma;
		this.acidity = acidity;
		this.body = body;
	}

	/**
	 * 
	 * @return origin
	 */
	public String getOrigin() {
		return origin;
	}

	/**
	 * set the origin of coffee
	 * @param origin
	 */
	public void setOrigin(String origin) {
		this.origin = origin;
	}

	/**
	 * get the roast of coffee
	 * @return roast
	 */
	public String getRoast() {
		return roast;
	}

	/**
	 * set the roast of coffee
	 * @param roast
	 */
	public void setRoast(String roast) {
		this.roast = roast;
	}

	/**
	 * get the flavor of coffee
	 * @return flavor
	 */
	public String getFlavor() {
		return flavor;
	}

	/**
	 * set the flavor of coffee
	 * @param flavor
	 */
	public void setFlavor(String flavor) {
		this.flavor = flavor;
	}

	/**
	 * get the aroma of coffee
	 * @return aroma
	 */
	public String getAroma() {
		return aroma;
	}

	/**
	 * set the aroma of coffee
	 * @param aroma
	 */
	public void setAroma(String aroma) {
		this.aroma = aroma;
	}

	/**
	 * get the acidity of coffee
	 * @return acidity
	 */
	public String getAcidity() {
		return acidity;
	}

	/**
	 * set the acidity of coffee
	 * @param acidity
	 */
	public void setAcidity(String acidity) {
		this.acidity = acidity;
	}

	/**
	 * get the body of coffee
	 * @return body
	 */
	public String getBody() {
		return body;
	}

	/**
	 * set the body of coffee
	 * @param body
	 */
	public void setBody(String body) {
		this.body = body;
	}
	
	/**
	 * override the function toString to show the information of the coffee
	 */
	@Override
	public String toString(){
		String str ="Code:  "+this.getCode()+"\n"+"Description: "+this.getDescription()+"\n"+"Price: "+this.getPrice()+"\n"+"Amount: "+this.getAmount()+"\n"+"Origin: "+this.origin+"\n"+"Roast: "+this.roast+"\n"+"Flavor: "+this.flavor+"\n"+"Aroma: "+this.aroma+"\n"+"Acidity: "+this.acidity+"\n"+"Body: "+this.body+"\n";
		return str;
	}
	

}
