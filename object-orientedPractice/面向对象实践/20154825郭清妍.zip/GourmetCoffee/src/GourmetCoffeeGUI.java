import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.border.LineBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;


import java.awt.Color;

import javax.swing.AbstractListModel;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.ScrollPane;
import java.awt.Font;
import java.awt.Frame;
import java.awt.HeadlessException;

import javax.swing.JLabel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

import javax.swing.ListSelectionModel;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.UIManager;
import java.awt.SystemColor;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.JRadioButton;
import javax.swing.SwingConstants;

/**
 * @version 1.0
 * @author guoqy
 * @func basic functions to display the UI
 */
public class GourmetCoffeeGUI {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private SalesFormatter salesformatter;
	private Order o;
	
	/**
	 * Launch the application.
	 */
	public void run() {
		try {
			GourmetCoffeeGUI window = new GourmetCoffeeGUI();
			window.frame.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the application.
	 */
	public GourmetCoffeeGUI() {
		try {
			FileCatalogInput file = new FileCatalogInput();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		ArrayList<Product> a = new ArrayList<Product>();
		o = new Order();
		Sales s = new Sales();
//		s.addOrder(o);
		JTextArea txtrHelloworld = new JTextArea();
		txtrHelloworld.setBackground(SystemColor.inactiveCaption);
		txtrHelloworld.setFont(new Font("Comic Sans MS", Font.PLAIN, 14));
		txtrHelloworld.setRows(100);
		txtrHelloworld.setColumns(50);
		JTextArea textArea_1 = new JTextArea();
		textArea_1.setColumns(25);
		textArea_1.setEditable(false);
		salesformatter = PlainTextSalesFormatter.getSingletonInstance();
		
		
		frame = new JFrame();
		frame.setBounds(100, 100, 622, 598);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		ScrollPane scrollPane = new ScrollPane();
		scrollPane.setForeground(Color.LIGHT_GRAY);
		scrollPane.setFont(new Font("Comic Sans MS", Font.PLAIN, 16));
		scrollPane.setBackground(Color.LIGHT_GRAY);
		scrollPane.setBounds(10, 22, 78, 324);
		frame.getContentPane().add(scrollPane);
		
		JList<String> jl = new JList<>(new MyListModel());
		jl.setBorder(new LineBorder(Color.WHITE, 2, true));
		jl.setFont(new Font("Calibri", Font.PLAIN, 16));
		scrollPane.add(jl);
		jl.addListSelectionListener(new ListSelectionListener(){
			@Override
			public void valueChanged(ListSelectionEvent e) {
				if(!jl.getValueIsAdjusting()){
//					System.out.println(jl.getSelectedValue());
					String code = jl.getSelectedValue();
						try {
							FileInputStream fin = new FileInputStream("Coffee.txt");
							ObjectInputStream in = new ObjectInputStream(fin);
							for(int i=0;i<24;i++){
								a.add((Product) in.readObject());
								if(i==jl.getSelectedIndex()){
//									System.out.println(a.get(i).toString());
							    	textArea_1.setText(a.get(i).toString());
								}
							}
							in.close();
							
						} catch (FileNotFoundException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (ClassNotFoundException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
				}
			}
		});
		
		JLabel lblCatalog = new JLabel("  Catalog");
		lblCatalog.setLabelFor(jl);
		lblCatalog.setFont(new Font("Calibri", Font.PLAIN, 18));
		lblCatalog.setBounds(10, 1, 78, 20);
		frame.getContentPane().add(lblCatalog);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 2, true));
		panel.setBounds(94, 22, 286, 249);
		
    	//textArea_1.setText(a.get(jl.getSelectedIndex()).toString());
		textArea_1.setLineWrap(true);
		textArea_1.setFont(new Font("Comic Sans MS", Font.PLAIN, 14));
		textArea_1.setBackground(SystemColor.controlHighlight);
		textArea_1.setRows(11);
		panel.add(textArea_1);
		
		frame.getContentPane().add(panel);
		
		JLabel lblProductInformation = new JLabel("Product Information");
		lblProductInformation.setFont(new Font("Calibri", Font.PLAIN, 18));
		lblProductInformation.setBounds(170, 4, 156, 15);
		frame.getContentPane().add(lblProductInformation);
		
		JLabel lblNewLabel = new JLabel("Quantity :");
		lblNewLabel.setFont(new Font("Calibri", Font.PLAIN, 18));
		lblNewLabel.setBounds(131, 281, 92, 20);
		frame.getContentPane().add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(233, 283, 66, 21);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblOrder = new JLabel("Order");
		lblOrder.setFont(new Font("Calibri", Font.PLAIN, 18));
		lblOrder.setBounds(456, 1, 66, 21);
		frame.getContentPane().add(lblOrder);
		
		JLabel lblTotal = new JLabel("Total :");
		lblTotal.setFont(new Font("Calibri", Font.PLAIN, 18));
		lblTotal.setBounds(416, 32, 72, 20);
		frame.getContentPane().add(lblTotal);
		
		textField_1 = new JTextField();
		textField_1.setBounds(491, 34, 66, 21);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		textField_1.setEditable(false);
		
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(400, 62, 194, 209);
		frame.getContentPane().add(scrollPane_1);
		
		JList<String> list = new JList<String>();
		list.setFont(new Font("Comic Sans MS", Font.PLAIN, 14));
		scrollPane_1.setViewportView(list);
		
		
		JButton btnNewButton = new JButton("Add|Modify Order Item");
		btnNewButton.setFont(new Font("Calibri", Font.PLAIN, 20));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(jl.getSelectedValue()==null){
					txtrHelloworld.setText("The Customer has not selected product.");
					return;
				}
				try {
					if(Integer.parseInt(textField.getText())<=0){
						txtrHelloworld.setText("Please enter an integer number.");
						return;
					}
				} catch (NumberFormatException e1) {
					txtrHelloworld.setText("Please enter the quantity you want to buy.");
					return;
				}
			    int num=Integer.valueOf(textField.getText());
			    OrderItem ot = new OrderItem(a.get(jl.getSelectedIndex()), num);		    
				   for(int i=0;i<num;i++){
					  o.addItem(ot);
				   }
				   textField_1.setText("��"+(float)o.getTotalCost());			
				   textField.setText("");
				if(0 == list.getModel().getSize())
			    {
			        DefaultListModel<String> listModel = new DefaultListModel<String>();
			        listModel.add(0,ot.toString());
			        list.setModel(listModel);
			    }
				 else
				    {
				        DefaultListModel<String> listModel= (DefaultListModel<String>) list.getModel();
				        listModel.add(listModel.getSize(),ot.toString());
				        list.setModel(listModel);
				    }
				ot.getProduct().setAmount(ot.getProduct().getAmount()-num);
//				System.out.println(ot.getProduct().getAmount());
			}
		});
		btnNewButton.setBounds(109, 311, 271, 35);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnRemoveOrderItem = new JButton("Remove Order Item");
		btnRemoveOrderItem.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(o.getNumberOfItems()==0){
					txtrHelloworld.setText("The current order is empty. ");
					return;
				}
				if(list.getSelectedValue()==null){
					txtrHelloworld.setText("The user has not selected an item in the order.");
					return;
				}
				 DefaultListModel<String> listModel= (DefaultListModel<String>) list.getModel();
//				    int num = list.getSelectedIndex();
//				    o.removeItem(num);
				 	String a = list.getSelectedValue().substring(0, 1);
//				 	System.out.println(a);
				 	int num = Integer.valueOf(a);
//				 	System.out.println(list.getSelectedIndex());
				 	for(int i=0;i<num;i++){
				 		o.removeItem(list.getSelectedIndex());
				 	}
				    listModel.remove(list.getSelectedIndex());
				    list.setModel(listModel);			  
			}
		});

		btnRemoveOrderItem.setFont(new Font("Calibri", Font.PLAIN, 18));
		btnRemoveOrderItem.setBounds(388, 274, 206, 35);
		frame.getContentPane().add(btnRemoveOrderItem);
		
		JButton btnRegisterOf = new JButton("Register Current Order");
		btnRegisterOf.addMouseListener(new MouseAdapter() {			
			@Override
			public void mouseClicked(MouseEvent e) {
				    Order o1 = o;
				    o=new Order();
				    s.addOrder(o1);
					txtrHelloworld.setText("Registered!\n");	
					if(0 == list.getModel().getSize())
				    {
				        DefaultListModel<String> listModel = new DefaultListModel<String>();
				        list.setModel(listModel);
				        txtrHelloworld.setText("Do Not have orders");
				    }
					else{
						DefaultListModel<String> listModel= (DefaultListModel<String>) list.getModel();
						listModel.removeAllElements();
						list.setModel(listModel);	
					}	
					
				 }
			
		});
		btnRegisterOf.setFont(new Font("Calibri", Font.PLAIN, 16));
		btnRegisterOf.setBounds(388, 311, 206, 35);
		frame.getContentPane().add(btnRegisterOf);
		
		JRadioButton rdbtnPlain = new JRadioButton("Plain");
		rdbtnPlain.setSelected(true);
		rdbtnPlain.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				salesformatter = PlainTextSalesFormatter.getSingletonInstance();
			}
		});
		rdbtnPlain.setFont(new Font("Calibri", Font.PLAIN, 16));
		rdbtnPlain.setBounds(6, 530, 92, 23);
		frame.getContentPane().add(rdbtnPlain);
		
		JRadioButton rdbtnHtml = new JRadioButton("HTML");
		rdbtnHtml.addMouseListener(new MouseAdapter(){
			@Override
			public void mouseClicked(MouseEvent e){
				salesformatter = HTMLSalesFormatter.getSingletonInstance();
			}
		});
		rdbtnHtml.setFont(new Font("Calibri", Font.PLAIN, 16));
		rdbtnHtml.setBounds(119, 530, 104, 23);
		frame.getContentPane().add(rdbtnHtml);
		
		JRadioButton rdbtnXml = new JRadioButton("XML");
		rdbtnXml.addMouseListener(new MouseAdapter(){
			@Override
			public void mouseClicked(MouseEvent e){
				salesformatter = XMLSalesFormatter.getSingletonInstance();
			}
		});
		frame.getContentPane().add(rdbtnXml);
		
		ButtonGroup bg = new ButtonGroup();
		bg.add(rdbtnPlain);
		bg.add(rdbtnHtml);
		bg.add(rdbtnXml);
		
		rdbtnXml.setFont(new Font("Calibri", Font.PLAIN, 16));
		rdbtnXml.setBounds(233, 530, 66, 23);
		
		JLabel lblStatus = new JLabel("Status");
		lblStatus.setFont(new Font("Calibri", Font.PLAIN, 18));
		lblStatus.setBounds(20, 355, 92, 26);
		frame.getContentPane().add(lblStatus);
		
		JButton btnDisplaySales = new JButton("Display Sales");
		btnDisplaySales.addMouseListener(new MouseAdapter(){
			@Override
			public void mouseClicked(MouseEvent e){
				txtrHelloworld.setText(salesformatter.formatSales(s));

			}
		});
		btnDisplaySales.setFont(new Font("Calibri", Font.PLAIN, 16));
		btnDisplaySales.setBounds(305, 530, 143, 23);
		frame.getContentPane().add(btnDisplaySales);
		
		JButton btnSaveSales = new JButton("Save Sales");
		btnSaveSales.addMouseListener(new MouseAdapter(){
			@Override
			public void mouseClicked(MouseEvent e){
				File file=null;
				JFileChooser fileChooser = new JFileChooser();
				try {
					int value = fileChooser.showSaveDialog(btnSaveSales);
					if(value==JFileChooser.APPROVE_OPTION){
						file = fileChooser.getSelectedFile();
						if(file.exists()==false){
							file.createNewFile();
						}
					}else{
						txtrHelloworld.setText("Note: User closes the file chooser without selecting a file.");
						return;
					}
					FileOutputStream fos = new FileOutputStream(file);
					OutputStreamWriter osw = new OutputStreamWriter(fos);
					String str = salesformatter.formatSales(s);
					osw.write(str);
					osw.close();
					txtrHelloworld.setText("Saved successfully!");
					
				} catch (HeadlessException e1) {
					e1.printStackTrace();
				} catch (IOException e1) {
					txtrHelloworld.setText("The file specified by the user cannot be created or opened.");
					return;
				}
			}
		});
		btnSaveSales.setFont(new Font("Calibri", Font.PLAIN, 16));
		btnSaveSales.setBounds(456, 530, 138, 23);
		frame.getContentPane().add(btnSaveSales);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		frame.getContentPane().add(scrollPane_2);
		scrollPane_2.setBounds(10, 385, 584, 139);
		txtrHelloworld.setRows(100);
		txtrHelloworld.setBackground(SystemColor.inactiveCaption);
		txtrHelloworld.setColumns(50);
		scrollPane_2.setViewportView(txtrHelloworld);
}
}

class MyListModel extends AbstractListModel<String>{
	private String[] contents = {"C001","C002","C003","C004","C005","C006","C007","C008","C009","C010","C011","C012","B001","B002","B003","B004","B005","A001","A002","A003","A004","A005","A006","A007","A008","A009"};
	@Override
	public String getElementAt(int x) {
		if(x<contents.length){
			return contents[x++];
		}
		else
			return null;
	}

	@Override
	public int getSize() {
		return contents.length;
	}
}

