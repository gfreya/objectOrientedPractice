
public class HTMLSalesFormatter implements SalesFormatter{
	private static HTMLSalesFormatter singletonInstance = null;
	
	static public HTMLSalesFormatter getSingletonInstance(){
		if(singletonInstance == null){
			singletonInstance = new HTMLSalesFormatter();
		}
		return singletonInstance;
	}
	
	private HTMLSalesFormatter(){
		
	}
	
	public String formatSales(Sales sales){
		String str="";
		str+="<html>\n"+" <body>\n"+"  <center><h2>Orders</h2></center>";
		for(Order o :sales.orders){
			str+="  <hr>\n";
			str+="  <h4>Total ="+(float)o.getTotalCost()+"</h4>\n";
			for(int j=0;j<o.getItems().size();){
				str+="  <p>\n"+"   <b>code:</b>"+o.getItems().get(j).getProduct().getCode()+"<br>\n";
				str+="   <b>quantity:</b>"+o.getItems().get(j).getQuantity()+"<br>\n";
				str+="   <b>price:<b>"+o.getItems().get(j).getProduct().getPrice()+"<br>\n"+"</p>\n";
				j=j+o.getItems().get(j).getQuantity();
			}
		}
		str+=" </body>\n"+"</html>\n";
		return str;
	}
}
