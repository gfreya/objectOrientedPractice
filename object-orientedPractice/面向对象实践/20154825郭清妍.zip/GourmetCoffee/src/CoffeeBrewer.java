import java.io.Serializable;

/**
 * @para three parameters: model waterSupply numberOfCups
 * @func basic functions of getting and setting the attributes of the product 
 * 		 overrides the toString method to show the information of the product
 * @version 1.0
 * @author Guoqy
 *
 */
public class CoffeeBrewer extends Product implements Serializable{
	private String model;
	private String waterSupply;
	private int numberOfCups;
	
	/**
	 * constructor
	 * @param code
	 * @param description
	 * @param price
	 * @param model
	 * @param waterSupply
	 * @param numberOfCups
	 */
	public CoffeeBrewer(String code,String description,double price,int amount,String model,String waterSupply,int numberOfCups){
		super(code,description,price,amount);
		this.model = model;
		this.waterSupply = waterSupply;
		this.numberOfCups = numberOfCups;
	}

	/**
	 * get the model of the coffee brewer
	 * @return model
	 */
	public String getModel() {
		return model;
	}

	/**
	 * set the model of the coffee brewer
	 * @param model
	 */
	public void setModel(String model) {
		this.model = model;
	}

	/**
	 * get the water supply of the coffee brewer
	 * @return water supply
	 */
	public String getWaterSupply() {
		return waterSupply;
	}

	/**
	 * set the water supply of the coffee brewer
	 * @param waterSupply
	 */
	public void setWaterSupply(String waterSupply) {
		this.waterSupply = waterSupply;
	}

	/**
	 * get the number of cups of the coffee brewer
	 * @return number of cups (integer)
	 */
	public int getNumberOfCups() {
		return numberOfCups;
	}

	/**
	 * set the number of cups of the coffee brewer
	 * @param numberOfCups
	 */
	public void setNumberOfCups(int numberOfCups) {
		this.numberOfCups = numberOfCups;
	}
	
	/**
	 * override the function toString to show the information of the coffee brewer
	 */
	@Override
	public String toString(){
		String str ="Code: "+this.getCode()+"\n"+"Description: "+this.getDescription()+"\n"+"Price: "+this.getPrice()+"\n"+"Model: "+this.model+"\n"+"Water Supply: "+this.waterSupply+"\n"+"Number of cups: "+this.numberOfCups+"\n";
		return str;
	}
	
}
