import java.io.Serializable;

/**
 * @para no parameter
 * @func basic function of the constructor
 * @version 1.0
 * @author Guoqy
 *
 */
public class CoffeeAccessory extends Product implements Serializable{

	/**
	 * constructor
	 * @param code
	 * @param description
	 * @param price
	 */
	public CoffeeAccessory(String code, String description, double price,int amount) {
		super(code, description, price,amount);
	}
	
}
