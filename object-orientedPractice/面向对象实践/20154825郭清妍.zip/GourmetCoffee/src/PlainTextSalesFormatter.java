
public class PlainTextSalesFormatter implements SalesFormatter {
	private static PlainTextSalesFormatter singletonInstance=null;
	
    static public PlainTextSalesFormatter getSingletonInstance(){
    	if(singletonInstance==null){
    		singletonInstance = new PlainTextSalesFormatter();
    	}
    	return singletonInstance;
    }
    
    private PlainTextSalesFormatter(){
    	
    }
    
    public String formatSales(Sales sales){
    	String str = "";
    	int i = 1;
    	for(Order o : sales.orders){
    		str+="-----------------\n"+"Order "+i+"\n";
    		for(int j =0;j<o.getItems().size();){
				str+=o.getItems().get(j).getQuantity()+" "+o.getItems().get(j).getProduct().getCode()+" "+o.getItems().get(j).getProduct().getPrice()+"\n";
				j=j+o.getItems().get(j).getQuantity();
    		}
//    			
    		str+=(float)o.getTotalCost()+"\n";
    		i++;
         }
    	return str;
     }
    
}
