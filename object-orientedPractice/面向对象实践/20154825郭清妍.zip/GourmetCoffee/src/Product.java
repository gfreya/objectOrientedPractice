import java.io.Serializable;

/**
 * @para three parameters: code description and price
 * @func basic functions for setting and getting the attribute 
 * 		 toString to show the total information
 * @version 1.0
 * @author guoqy
 *
 */
public class Product implements Serializable{
	private String code;
	private String description;
	private double price;
	private int amount;
	
	/**
	 * constructor
	 * @param code
	 * @param description
	 * @param price
	 */
	public Product(String code,String description,double price,int amount){
		this.code= code;
		this.description = description;
		this.price = price;
		this.amount = amount;
	}

	public int getAmount(){
		return amount;
	}
	
	public void setAmount(int amount){
		this.amount = amount;
	}
	
	/**
	 * basic get method: get the code of the product
	 * @return String code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * basic set method : set the code of the product
	 * @param code
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * basic get method : get the description of the product
	 * @return String description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * basic set method : set the description of the product
	 * @param description
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
	/**
	 * basic get method: get the price of the product
	 * @return price
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * basic set method : set the price of the product
	 * @param price
	 */
	public void setPrice(double price) {
		this.price = price;
	}

	/**
	 * check if the object is an instance of the class Product
	 */
	public boolean equals(Object object){
		if(object instanceof Product){
			return ((Product) object).getCode().equals(code);
		}
		else{
			return false;
		}
	}
	
	/**
	 * override the toString method to show the  detail information of the product
	 */
	@Override
	public String toString() {
		String str;
		str ="Code:   "+this.code+"\n"+"Description:  "+this.description+"\n"+"Price:  "+this.price+"\n"+"Amount: "+this.amount+"\n";
		return str;
	}
	
	
}
