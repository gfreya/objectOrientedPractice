import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class LoginIn {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginIn window = new LoginIn();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LoginIn() {
		FileLoginIn f = new FileLoginIn();
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 633, 459);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblWelcomeToGourmet = new JLabel("Welcome To Gourmet Coffee System");
		lblWelcomeToGourmet.setFont(new Font("Calibri", Font.PLAIN, 26));
		lblWelcomeToGourmet.setBounds(108, 34, 426, 45);
		frame.getContentPane().add(lblWelcomeToGourmet);
		
		JLabel lblName = new JLabel("Name: ");
		lblName.setFont(new Font("Calibri", Font.PLAIN, 24));
		lblName.setBounds(161, 129, 77, 31);
		frame.getContentPane().add(lblName);
		
		textField = new JTextField();
		textField.setBounds(297, 124, 141, 36);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnLoginIn = new JButton("Login In");
		btnLoginIn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					File f = new File("name.dat");
					FileReader fr = new FileReader(f);
					BufferedReader bre = new BufferedReader(fr);
					String str ="";
					File f1 = new File("Number.dat");
					FileReader fr1 =new FileReader(f1);
					BufferedReader bre1 = new BufferedReader(fr1);
					String str1 ="";
					while(((str=bre.readLine())!=null)&&((str1=bre1.readLine())!=null)){
						if((str.contains(textField.getText()))&&(str1.contains(textField_1.getText()))){
//							System.out.println("Done");
							frame.setVisible(false);	
							GourmetCoffeeGUI gui = new GourmetCoffeeGUI();
							gui.run();
						}	
						else{
							JOptionPane.showMessageDialog(null, "Please Enter the right information to login in.", "Note", JOptionPane.INFORMATION_MESSAGE);
						}
					}
					bre.close();
					fr.close();
					bre1.close();
					fr1.close();
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnLoginIn.setFont(new Font("Calibri", Font.PLAIN, 24));
		btnLoginIn.setBounds(251, 328, 152, 31);
		frame.getContentPane().add(btnLoginIn);
		
		JLabel lblNumber = new JLabel("Number:");
		lblNumber.setFont(new Font("Calibri", Font.PLAIN, 24));
		lblNumber.setBounds(157, 219, 94, 31);
		frame.getContentPane().add(lblNumber);
		
		textField_1 = new JTextField();
		textField_1.setBounds(297, 219, 141, 36);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
	}
}
