import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class FileCatalogInput {
		public FileCatalogInput() throws IOException{
		
		Coffee c1 = new Coffee("C001","Colombia, Whole, 1 lb",17.99,26,"Colombia","Medium","Rich and Hearty","Rich","Medium","Whole");
		Coffee c2 = new Coffee("C002","Colombia, Ground, 1 lb",18.75,34,"Colombia","Medium","Rich and Hearty","Rich","Medium","Ground");
		Coffee c3 = new Coffee("C003","Italian Roast, Whole, 1 lb",16.8,29,"Latin American Blend","Italian Roast","Dark and heavy","Intense","Low","Medium");
		Coffee c4 = new Coffee("C004","Italian Roast, Ground, 1 lb",17.55,59,"Latin American Blend","Italian Roast","Dark and heavy","Intense","Low","Medium");
		Coffee c5 = new Coffee("C005","French Roast, Whole, 1 lb",16.8,67,"Latin American Blend","French Roast","Bittersweet, full intense","Intense, full","None","Medium");
		Coffee c6 = new Coffee("C006","French Roast, Ground, 1 lb",17.55,45,"Latin American Blend","French Roast","Bittersweet, full intense","Intense, full","None","Medium");
		Coffee c7 = new Coffee("C007","Guatemala, Whole, 1 lb",17.99,33,"Guatemala","Medium","Rich and complex","Spicy","Medium to high","Medium to full");
		Coffee c8 = new Coffee("C008","Guatemala, Ground, 1 lb",18.75,22,"Guatemala","Medium","Rich and complex","Spicy","Medium to high","Medium to full");
		Coffee c9 = new Coffee("C009","Sumatra, Whole, 1 lb",19.99,30,"Sumatra","Medium","Vibrant and powdery","Like dark chocolate","Gentle","Rich and full");
		Coffee c10 = new Coffee("C010","Sumatra, Ground, 1 lb",20.5,66,"Sumatra","Medium","Vibrant and powdery","Like dark chocolate","Gentle","Rich and full");
		Coffee c11 = new Coffee("C011","Decaf Blend, Whole, 1 lb",16.8,48,"Latin American Blend","Dark roast","Full, roasted flavor","Hearty","Bold and rich","Full");
		Coffee c12 = new Coffee("C012","Decaf Blend, Ground, 1 lb",17.55,23,"Latin American Blend","Dark roast","Full, roasted flavor","Hearty","Bold and rich","Full");
		
		CoffeeBrewer cb1 = new CoffeeBrewer("B001","Home Coffee Brewer",150.0,5,"Brewer 100","Pourover",6);
		CoffeeBrewer cb2 = new CoffeeBrewer("B002","Coffee Brewer, 2 Warmers",200.0,6,"Brewer 200","Pourover",12);
		CoffeeBrewer cb3 = new CoffeeBrewer("B003","Coffee Brewer, 3 Warmers",280.0,8,"Brewer 210","Pourover",12);
		CoffeeBrewer cb4 = new CoffeeBrewer("B004","Commercial Coffee, 20 Cups",380.0,9,"Quick Coffee 100","Automatic",20);
		CoffeeBrewer cb5 = new CoffeeBrewer("B005","Commercial Coffee, 40 Cups",480.0,7,"Quick Coffee 200","Automatic",40);
		
		CoffeeAccessory ca1 = new CoffeeAccessory("A001","Almond Flavored Syrup",9.0,9);
		CoffeeAccessory ca2 = new CoffeeAccessory("A002","Irish Creme Flavored Syrup",9.0,10);
		CoffeeAccessory ca3 = new CoffeeAccessory("A003","Mint Flavored syrup",9.0,5);
		CoffeeAccessory ca4 = new CoffeeAccessory("A004","Caramel Flavored Syrup",9.0,8);
		CoffeeAccessory ca5 = new CoffeeAccessory("A005","Gourmet Coffee Cookies",12.0,10);
		CoffeeAccessory ca6 = new CoffeeAccessory("A006","Gourmet Coffee Travel Thermo",18.0,8);
		CoffeeAccessory ca7 = new CoffeeAccessory("A007","Gourmet Coffee Ceramic Mug",8.0,9);
		CoffeeAccessory ca8 = new CoffeeAccessory("A008","Gourmet Coffee 12 Cup Filters",15.0,7);
		CoffeeAccessory ca9 = new CoffeeAccessory("A009","Gourmet Coffee 36 Cup Filters",45.0,11);

		//System.out.println(c1.toString());
		
		FileOutputStream fout = new FileOutputStream("Coffee.txt");
		ObjectOutputStream oos = new ObjectOutputStream(fout);
		
		oos.writeObject(c1);
		oos.writeObject(c2);
		oos.writeObject(c3);
		oos.writeObject(c4);
		oos.writeObject(c5);
		oos.writeObject(c6);
		oos.writeObject(c7);
		oos.writeObject(c8);
		oos.writeObject(c9);
		oos.writeObject(c10);
		oos.writeObject(c11);
		oos.writeObject(c12);
		
		oos.writeObject(cb1);
		oos.writeObject(cb2);
		oos.writeObject(cb3);
		oos.writeObject(cb4);
		oos.writeObject(cb5);
		
		oos.writeObject(ca1);
		oos.writeObject(ca2);
		oos.writeObject(ca3);
		oos.writeObject(ca4);
		oos.writeObject(ca5);
		oos.writeObject(ca6);
		oos.writeObject(ca7);
		oos.writeObject(ca8);
		oos.writeObject(ca9);
				
		fout.close();
		
		File file= new File("CoffeeInformation.txt");
		FileWriter out = new FileWriter(file);
		
		out.write(c1.toString());
		out.write(c2.toString());
		out.write(c3.toString());
		out.write(c4.toString());
		out.write(c5.toString());
		out.write(c6.toString());
		out.write(c7.toString());
		out.write(c8.toString());
		out.write(c9.toString());
		out.write(c10.toString());
		out.write(c11.toString());
		out.write(c12.toString());
		
		out.write(cb1.toString());
		out.write(cb2.toString());
		out.write(cb3.toString());
		out.write(cb4.toString());
		out.write(cb5.toString());
		
		out.write(ca1.toString());
		out.write(ca2.toString());
		out.write(ca3.toString());
		out.write(ca4.toString());
		out.write(ca5.toString());
		out.write(ca6.toString());
		out.write(ca7.toString());
		out.write(ca8.toString());
		out.write(ca9.toString());
		
		out.close();
		
	}
}
