import java.io.Serializable;

/**
 * @para two parameters : product and quantity
 * @func basic functions for gettting and setting the attribute of the order item
 * 	     override the function toString to show the information of the order item
 * @version 1.0
 * @author Guoq
 *
 */
public class OrderItem {
	private Product product;
	private int quantity;
	
	/**
	 * constructor
	 * @param product
	 * @param quantity
	 */
	public OrderItem(Product product, int quantity) {
		this.product = product;
		this.quantity = quantity;
	}

	/**
	 * get the product chose
	 * @return product
	 */
	public Product getProduct() {
		return product;
	}

	/**
	 * set the product
	 * @param product
	 */
	public void setProduct(Product product) {
		this.product = product;
	}

	/**
	 * get the quantity bought
	 * @return int quantity
	 */
	public int getQuantity() {
		return quantity;
	}

	/**
	 * set the quantity of the product
	 * @param quantity
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	/**
	 * get the price of the product being chosen
	 * @return
	 */
	public double getValue(){
		return product.getPrice();
	}
	
	/**
	 * override the function toString to show the information of the order item
	 */
	@Override
	public String toString(){
		String str =this.quantity+"_"+this.product.getCode()+"_"+this.product.getPrice();
		return str;
	}
	
}
