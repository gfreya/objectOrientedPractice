import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
/**
 * @para one parameter : ArrayList items of  OrderItem
 * @func basic function for adding and removing item to the ArrayList items
 * 		 return the item of the ArrayList, the number of the ArrayList and the cost for all the items of the ArrayList
 * @version 1.0
 * @author Guoqy
 *
 */

public class Order{
	private ArrayList<OrderItem> items;
	
	/**
	 * constructor
	 */
	public Order(){
		items = new ArrayList<OrderItem>();
	}
	
	/**
	 * get the Array List of the order items
	 * @return ArrayList 
	 */
	public ArrayList<OrderItem> getItems() {
		return items;
	}

	/**
	 * add item of the ArrayList items
	 * @param orderitem
	 */
	public void addItem(OrderItem orderitem){
		items.add(orderitem);
	}
	
	/**
	 * remove the item of the ArrayList items
	 * @param orderitem
	 */
	
	public void removeItem(int num){
		items.remove(num);
	}
	
	/**
	 * return a collection of iteration
	 * @return iterator
	 */
	public Iterator<OrderItem> iterator(){
		Iterator<OrderItem> i = items.iterator();
		return i;
	}
	
	/**
	 * return the OrderItem of the ArrayList items 
	 * @param product
	 * @return OrderItem
	 */
	public boolean getItem(Product product){
		for(OrderItem o :items){
			if(o.getProduct().equals(product)){
				return true;
			}
		}
		return false;
	}
	
	/**
	 * return the number of the item of the ArrayList
	 * @return integer
	 */
	public int getNumberOfItems(){
		int total = 0;
		for(OrderItem o :items){
			total = total +1;
		}
		return total;
	}
	
	/**
	 * return the total value of the items of the ArrayList
	 * @return double
	 */
	public double getTotalCost(){
		double cost = 0;
		for(OrderItem o :items){
			cost = cost + o.getValue();
		}
		return cost;
	}
	
	
}
