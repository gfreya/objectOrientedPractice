import java.util.*;
/**
 * @para one parameter : orders
 * @func add order to the ArrayList orders
 *       return the collections of order in iteration
 *       get the number of orders in the ArrayList orders
 * @version 1.0
 * @author guoqy
 *
 */
public class Sales {
	ArrayList<Order> orders;
	
	/**
	 * constructor
	 */
	public Sales(){
		orders = new ArrayList<Order>();
	}
	
	public ArrayList<Order> getOrders(){
		return orders;
	}
	
	/**
	 * add order to the ArrayList orders
	 * @param order
	 */
	public void addOrder(Order order){
		orders.add(order);
	}
	
	public void removeOrder(Order order){
		orders.remove(order);
	}
	
	/**
	 * get the collection orders in iteration
	 * @return
	 */
	public Iterator<Order> iterator(){
		Iterator<Order> i = orders.iterator();
		return i;
	}
	
	public int getNumberOfOrders(){
		int total = 0;
		for(Order o : orders){
			total = total +1;
		}
		return total;
	}
}
